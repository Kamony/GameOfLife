package gameoflife;

/**
 *
 * @author Jirka Hauser
 */
public class GOL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame life = new JFrame();
        life.setLocationRelativeTo(null);
        life.show();
    }
    
}
